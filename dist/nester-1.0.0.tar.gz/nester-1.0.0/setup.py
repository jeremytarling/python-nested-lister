from distutils.core import setup

setup(
    name  = 'nester',
    version = '1.0.0',
    py_modules = ['nester'],
    author  = 'jeremytarling',
    author_email = 'jeremy.tarling@gmail.com',
    url = 'http://www.topdrawersausage.net',
    description = 'a simple printer of nested lists',
    )

